// Gemini API client for YUTorah Notes Extension
// Refactored for Gemini 2.5 Flash and production robustness

const GeminiAPI = {
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',

    /**
     * Light cleanup for known Gemini LaTeX artifacts
     * (intentionally conservative)
     */
    cleanFormatting(text) {
        if (!text) return text;

        // Remove \text{...}
        text = text.replace(/\\text\{([^}]*)\}/g, '$1');

        // Remove wrapping $$ or $ only when clearly LaTeX-style
        text = text.replace(/\$\$([\s\S]*?)\$\$/g, '$1');

        return text.trim();
    },

    /**
     * Upload a file to Gemini using resumable upload
     */
    async uploadFile(apiKey, fileBlob, mimeType = 'audio/mpeg') {
        // File Upload API uses /upload/v1beta/files
        const initiateUrl = `https://generativelanguage.googleapis.com/upload/v1beta/files?key=${apiKey}`;

        console.log('Initiating upload to:', initiateUrl);

        const initiateResponse = await fetch(initiateUrl, {
            method: 'POST',
            headers: {
                'X-Goog-Upload-Protocol': 'resumable',
                'X-Goog-Upload-Command': 'start',
                'X-Goog-Upload-Header-Content-Length': fileBlob.size.toString(),
                'X-Goog-Upload-Header-Content-Type': mimeType,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                file: { display_name: 'yutorah_shiur.mp3' }
            })
        });

        if (!initiateResponse.ok) {
            const errorText = await initiateResponse.text();
            console.error('Upload initiation failed with status:', initiateResponse.status);
            console.error('Response headers:', [...initiateResponse.headers.entries()]);
            console.error('Error body:', errorText);
            throw new Error(`Upload failed (${initiateResponse.status}): ${errorText || 'No error details'}`);
        }

        const uploadUrl = initiateResponse.headers.get('X-Goog-Upload-URL');
        if (!uploadUrl) {
            throw new Error('Missing resumable upload URL');
        }

        const uploadResponse = await fetch(uploadUrl, {
            method: 'POST',
            headers: {
                'X-Goog-Upload-Command': 'upload, finalize',
                'X-Goog-Upload-Offset': '0',
                'Content-Type': mimeType
            },
            body: fileBlob
        });

        if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            console.error('File upload failed:', errorText);
            throw new Error(`File upload failed: ${errorText}`);
        }

        const fileData = await uploadResponse.json();
        await this.waitForFileProcessing(apiKey, fileData.file.name);

        return fileData.file;
    },

    /**
     * Poll until Gemini finishes processing the file
     */
    async waitForFileProcessing(apiKey, fileName, maxAttempts = 30) {
        for (let i = 0; i < maxAttempts; i++) {
            const res = await fetch(`${this.baseUrl}/${fileName}?key=${apiKey}`);
            const data = await res.json();

            if (data.state === 'ACTIVE') return;
            if (data.state === 'FAILED') {
                throw new Error('Gemini file processing failed');
            }

            await new Promise(r => setTimeout(r, 2000));
        }

        throw new Error('Timed out waiting for Gemini file processing');
    },

    /**
     * Generate transcript or notes
     */
    async generateContent(apiKey, fileUri, requestType = 'notes') {
        const model = 'gemini-2.5-flash';
        const url = `${this.baseUrl}/models/${model}:generateContent?key=${apiKey}`;

        const prompt =
            requestType === 'transcript'
                ? `Generate a verbatim or near-verbatim transcript of this audio shiur.

Rules:
- Identify speakers if possible.
- Hebrew terms must be written in Hebrew script.
- Do not summarize or explain.
- Mark unclear audio as [inaudible].

If you cannot process the audio, respond with exactly:
"ERROR: Unable to process audio file."`
                : `Take extensive, structured notes on this shiur in markdown.

Rules:
- English text, Hebrew terms in Hebrew script only.
- Markdown only (no HTML).
- Use ## / ### headers, bullet points, **bold** terms.
- Be comprehensive and well-organized.
- No preamble or meta commentary.

If you cannot process the audio, respond with exactly:
"ERROR: Unable to process audio file."`;

        const body = {
            contents: [
                {
                    parts: [
                        {
                            fileData: {
                                mimeType: 'audio/mpeg',
                                fileUri
                            }
                        },
                        { text: prompt }
                    ]
                }
            ],
            generationConfig: {
                temperature: 0.2,
                topP: 0.9,
                maxOutputTokens: 8192
            },
            safetySettings: [
                { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
                { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' }
            ]
        };

        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data = await response.json();
        const parts = data?.candidates?.[0]?.content?.parts;

        if (!Array.isArray(parts)) {
            throw new Error('No content generated by Gemini');
        }

        const text = parts
            .filter(p => typeof p.text === 'string')
            .map(p => p.text)
            .join('\n');

        return this.cleanFormatting(text);
    },

    /**
     * Download MP3
     */
    async downloadMP3(url) {
        const res = await fetch(url);
        if (!res.ok) throw new Error(`MP3 download failed: ${res.statusText}`);
        return res.blob();
    },

    /**
     * Scrape YUTorah page for MP3 URL
     * NOTE: must be run in background context or same-origin
     */
    async getMP3Url(pageUrl) {
        const res = await fetch(pageUrl);
        const html = await res.text();

        const doc = new DOMParser().parseFromString(html, 'text/html');

        for (const a of doc.querySelectorAll('a[href]')) {
            const href = a.getAttribute('href');
            if (href?.toLowerCase().endsWith('.mp3')) {
                return new URL(href, pageUrl).href;
            }
        }

        const audioSrc =
            doc.querySelector('audio')?.getAttribute('src') ||
            doc.querySelector('audio source')?.getAttribute('src');

        if (audioSrc) {
            return new URL(audioSrc, pageUrl).href;
        }

        throw new Error('No MP3 found on YUTorah page');
    },

    /**
     * Main pipeline
     */
    async processShiur(apiKey, pageUrl, requestType = 'notes', progress = null) {
        progress?.('Finding MP3...');
        const mp3Url = await this.getMP3Url(pageUrl);

        progress?.('Downloading audio...');
        const blob = await this.downloadMP3(mp3Url);

        progress?.('Uploading to Gemini...');
        const file = await this.uploadFile(apiKey, blob);

        progress?.('Generating output...');
        const result = await this.generateContent(apiKey, file.uri, requestType);

        progress?.('Done');
        return result;
    },

    /**
     * Process shiur from MP3 URL directly (no scraping needed)
     */
    async processShiurFromUrl(apiKey, mp3Url, requestType = 'notes') {
        console.log('Downloading audio from:', mp3Url);
        const blob = await this.downloadMP3(mp3Url);

        console.log('Uploading to Gemini...');
        const file = await this.uploadFile(apiKey, blob);

        console.log('Generating content...');
        const result = await this.generateContent(apiKey, file.uri, requestType);

        console.log('Processing complete');
        return result;
    }
};

// Export for extension / Node compatibility
if (typeof module !== 'undefined') {
    module.exports = GeminiAPI;
}
